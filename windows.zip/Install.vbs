Set objShell = CreateObject("Shell.Application")
Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
Set objFSO = CreateObject("Scripting.FileSystemObject")

strPath = objFSO.GetParentFolderName(WScript.ScriptFullName)
strBatFile = strPath & "\res\Install.bat"

' Run the batch file as admin
objShell.ShellExecute "cmd.exe", "/c """ & strBatFile & """", "", "runas", 0

' Get the batch file name to monitor
batName = "cmd.exe"

' Wait for the batch to start (cmd.exe process)
Do
    WScript.Sleep 500
    Set colProcesses = objWMIService.ExecQuery("Select * from Win32_Process Where Name = '" & batName & "'")
Loop Until colProcesses.Count > 0

' Now wait until all cmd.exe processes close
Do
    WScript.Sleep 1000
    Set colProcesses = objWMIService.ExecQuery("Select * from Win32_Process Where Name = '" & batName & "'")
Loop Until colProcesses.Count = 0

' After batch file finishes, show popup
CreateObject("WScript.Shell").Popup "BlueJ Theme Hub installed", 5, "Installation Complete", 64
