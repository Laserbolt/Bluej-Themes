@ECHO OFF
cd %~dp0

icacls "%ProgramFiles%\BlueJ\lib\stylesheets" /grant %username%:(OI^)(CI^)F /T
icacls "%ProgramFiles%\BlueJ\lib\extensions2" /grant %username%:(OI^)(CI^)F /T


robocopy . "%ProgramFiles%\BlueJ\lib\extensions2" ThemeHub.jar /r:3 /w:5
robocopy "Themes" "%ProgramFiles%\BlueJ\lib\stylesheets" /e /r:3 /w:5 /mt:8